---
layout: page
title: About
permalink: /about/
---

This is [Eugenio Culurciello's](https://engineering.purdue.edu/elab/html/contact-eugenio-culurciello.html) blog. I am a professor and an [entrepreneur](https://www.linkedin.com/in/eugenioculurciello) and I work on [technology](https://engineering.purdue.edu/elab/html/research.html).

You can find our e-Lab webpage at [elab/Purdue](https://engineering.purdue.edu/elab/index.html)

You can find Teradeep webpage at: [teradeep/webpage](http://teradeep.com)
